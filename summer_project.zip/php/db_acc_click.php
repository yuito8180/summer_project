<?php

    define("DB_NAME","yhasimoto");
    define("DB_HOST","localhost");
    define("CHARSET","utf8");

    define("USERNAME","yhasimoto");
    define("USERPASS","eccMyAdmin");

?>