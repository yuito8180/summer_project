<?php

    define("DB_NAME","peace");
    define("DB_HOST","localhost");
    define("CHARSET","utf8");

    define("USERNAME","root");
    define("USERPASS","root");

?>